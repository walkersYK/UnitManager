package com.zhiyi.service;

import com.zhiyi.model.entity.UnitInventory;
import java.util.List;

public interface UnitInventoryService {
    List<UnitInventory> findAll();
    UnitInventory findById(Integer id);
    List<UnitInventory> findByUnitId(Integer unitId);
    void save(UnitInventory unitInventory);
    void update(UnitInventory unitInventory);
    void deleteById(Integer id);
}