package com.zhiyi.service.impl;

import com.zhiyi.mapper.UnitMapper;
import com.zhiyi.model.entity.Unit;
import com.zhiyi.service.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class UnitServiceImpl implements UnitService {

    @Autowired
    private UnitMapper unitMapper;

    @Override
    public List<Unit> findAll() {
        return unitMapper.findAll();
    }

    @Override
    public Unit findById(Integer id) {
        return unitMapper.findById(id);
    }

    @Override
    public void save(Unit unit) {
        unitMapper.insert(unit);
    }

    @Override
    public void update(Unit unit) {
        unitMapper.update(unit);
    }
    @Override
    @Transactional //确保批量操作是在一个事务中完成
    public void saveBatch(List<Unit> units) {
        unitMapper.saveBatch(units);
    }

    @Override
    public void deleteById(Integer id) {
        unitMapper.deleteById(id);
    }

    @Override
    public List<Unit> findByDeviceName(String deviceName) {
        return unitMapper.findByDeviceName(deviceName);
    }

    @Override
    public List<Unit> getTopFiveByStockAsc() {
        return unitMapper.selectTopFiveByStockAsc();
    }
    @Override
    public int getTotalUnitCount() {
        return unitMapper.countUnits();
    }
}