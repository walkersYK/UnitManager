package com.zhiyi.service;

import com.zhiyi.model.entity.Post;
import java.util.List;

public interface PostService {

    List<Post> findAll();

    Post findById(Long id);

    void save(Post post);

    void update(Post post);

    void deleteById(Long id);

    // 新增：根据标题搜索帖子
    List<Post> findByTitle(String title);
}