package com.zhiyi.model.entity;

import lombok.Data;

import java.util.Date;
@Data
public class UnitInventory {
    private Integer id;
    private Integer unitId;
    private Integer stock;
    private Date lastModified;
    private Integer modifierId;
    private String modifierName;
    private String changeReason;

    // Getters and Setters
}