package com.zhiyi.model.entity;

import lombok.Data;

import java.util.Date;
@Data
public class PostComments {
    private Long id;
    private Long postId;
    private Long userId;
    private String userName;
    private String content;
    private Date createdAt;
    private Date updatedAt;
    private Integer isDelete;

    // Getters and Setters
}