package com.zhiyi.mapper;

import com.zhiyi.model.entity.PostComments;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostCommentsMapper {

    List<PostComments> findAll();

    PostComments findById(@Param("id") Long id);

    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(PostComments postComments);

    void update(PostComments postComments);

    void deleteById(@Param("id") Long id);
}