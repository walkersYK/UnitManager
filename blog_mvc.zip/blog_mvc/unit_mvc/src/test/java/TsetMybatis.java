/**
 * @author YunJin
 * @version 1.0
 * @description: TODO
 * @date 2024/11/26 15:44
 */
import com.zhiyi.mapper.UserMapper;
import com.zhiyi.model.entity.User;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.util.List;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"classpath:applicationContext.xml"})
public class TsetMybatis {

    @Autowired
    private UserMapper userMapper;

    @Before
    public void setSqlSession() throws IOException {

    }

    @Test
    public void testQueryUsersBySql() {
        List<User> users = userMapper.queryUsersBySql(0, 10); // 查询第一页，每页10条记录
        System.out.println(users);
    }
}
