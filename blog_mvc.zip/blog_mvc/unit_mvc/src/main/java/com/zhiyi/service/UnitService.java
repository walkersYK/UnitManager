package com.zhiyi.service;

import com.zhiyi.model.entity.Unit;
import java.util.List;

public interface UnitService {

    List<Unit> findAll();

    Unit findById(Integer id);

    void save(Unit unit);

    void update(Unit unit);

    void deleteById(Integer id);

    // 根据 device_name 搜索相关的元器件
    List<Unit> findByDeviceName(String deviceName);

    List<Unit> getTopFiveByStockAsc();
    void saveBatch(List<Unit> units);
   int getTotalUnitCount();
}