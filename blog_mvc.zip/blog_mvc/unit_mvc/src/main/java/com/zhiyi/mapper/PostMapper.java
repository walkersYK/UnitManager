package com.zhiyi.mapper;

import com.zhiyi.model.entity.Post;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PostMapper {

    List<Post> findAll();


    Post findById(@Param("id") Long id);


    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Post post);


    void update(Post post);


    void deleteById(@Param("id") Long id);

    List<Post> findByTitle(@Param("title") String title);
}