package com.zhiyi.mapper;

import com.zhiyi.model.entity.Unit;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UnitMapper {

    List<Unit> findAll();


    Unit findById(@Param("id") Integer id);


    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Unit unit);


    void update(Unit unit);


    void deleteById(@Param("id") Integer id);
    void saveBatch(@Param("units") List<Unit> units);


    // 根据 device_name 搜索相关的元器件
    List<Unit> findByDeviceName(@Param("deviceName") String deviceName);

    List<Unit> selectTopFiveByStockAsc();

    int countUnits();
}