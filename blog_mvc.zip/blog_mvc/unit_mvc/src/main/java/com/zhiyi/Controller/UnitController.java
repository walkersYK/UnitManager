package com.zhiyi.Controller;

import cn.hutool.poi.excel.ExcelReader;
import cn.hutool.poi.excel.ExcelUtil;
import com.alibaba.excel.EasyExcel;
import com.zhiyi.common.BaseResponse;
import com.zhiyi.common.ResultUtils;
import com.zhiyi.model.entity.Result;
import com.zhiyi.model.entity.Unit;
import com.zhiyi.service.UnitService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/units")
public class UnitController {

    @Resource
    private UnitService unitService;

    @GetMapping("/all")
    public List<Unit> getAllUnits() {
        return unitService.findAll();
    }

    @GetMapping("/{id}")
    public Unit getUnitById(@PathVariable Integer id) {
        return unitService.findById(id);
    }

    @PostMapping("/add")
    public void addUnit(@RequestBody Unit unit) {
        unitService.save(unit);
    }

    @PutMapping("/{id}")
    public void updateUnit(@PathVariable Integer id, @RequestBody Unit unit) {
        unit.setId(id);
        unitService.update(unit);
    }
    @DeleteMapping("/{id}")
    public void deleteUnit(@PathVariable Integer id) {
        unitService.deleteById(id);
    }

    // 根据 device_name 搜索相关的元器件
    @GetMapping("/search")
    public List<Unit> searchUnitsByName(@RequestParam("deviceName") String deviceName) {
        return unitService.findByDeviceName(deviceName);
    }
    @GetMapping("/count")
    public int getUnitCount() {
        return unitService.getTotalUnitCount();
    }

    @GetMapping("/top-five-by-stock")
    public List<Unit> getTopFiveByStockAsc() {
        return unitService.getTopFiveByStockAsc();
    }

    @PostMapping("/imFile")
    public BaseResponse importData(MultipartFile file) throws IOException{
        ExcelReader reader = ExcelUtil.getReader(file.getInputStream());
        List<Unit> unitList = reader.readAll(Unit.class);
        unitService.saveBatch(unitList);
        return ResultUtils.success(unitList);
    }
}