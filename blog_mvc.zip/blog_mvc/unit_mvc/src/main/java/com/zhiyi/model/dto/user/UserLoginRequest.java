package com.zhiyi.model.dto.user;

import lombok.Data;

import java.io.Serializable;

/**
 * 用户登录请求
 *数据传输对象
@ function 作为控制器层（Controller）和业务逻辑层（Service）之间传递数据的载体，简化参数传递，接收前端传来的参数自动映射

 */
@Data
public class UserLoginRequest implements Serializable {

    private static final long serialVersionUID = 3191241716373120793L;

    private String userAccount;

    private String userPassword;

    private Boolean rememberMe;
}
