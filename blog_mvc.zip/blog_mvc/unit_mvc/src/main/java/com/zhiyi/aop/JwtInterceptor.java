package com.zhiyi.aop;

/**
 * 功能：校验拦截器规则
 *
 * @anther 韵锦
 * @from
 */
import cn.hutool.core.util.StrUtil;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.zhiyi.common.ErrorCode;
import com.zhiyi.mapper.UserMapper;
import com.zhiyi.model.entity.User;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class JwtInterceptor implements HandlerInterceptor {

    @Resource
    private UserMapper userMapper;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String token = request.getHeader("token");
        if (StrUtil.isBlank(token)) {
            token = request.getParameter("token");
        }
        // 如果不是映射到方法直接通过
        if (handler instanceof HandlerMethod) {
            AuthAccess annotation = ((HandlerMethod) handler).getMethodAnnotation(AuthAccess.class);
            if (annotation != null) {
                return true;
            }
        }
        // 执行认证
        if (StrUtil.isBlank(token)) {
            System.out.println(ErrorCode.FORBIDDEN_ERROR);
        }
        // 获取 token 中的 user id
        String userId = " ";
        try {
            userId = JWT.decode(token).getAudience().get(0);
        } catch (JWTDecodeException j) {
            System.out.println(ErrorCode.NOT_LOGIN_ERROR);;
        }
        // 根据token中的userid查询数据库
        User user = userMapper.selectUserById(Long.valueOf(userId));
        if (user == null) {
            System.out.println(ErrorCode.NOT_LOGIN_ERROR);;
        }
        // 用户密码加签验证 token
        JWTVerifier jwtVerifier = JWT.require(Algorithm.HMAC256(user.getUserPassword())).build();
        try {
            jwtVerifier.verify(token); // 验证token
        } catch (JWTVerificationException e) {
            System.out.println(ErrorCode.NOT_LOGIN_ERROR);;
        }
        return true;
    }
}
