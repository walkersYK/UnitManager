package com.zhiyi.model.entity;

import cn.hutool.core.annotation.Alias;
import com.alibaba.excel.annotation.ExcelProperty;
import lombok.Data;

@Data
public class Unit {
    @Alias("编号")
    private Integer id;
    @Alias("设备名称")
    private String deviceName;
    @Alias("设备数量")
    private String modelNumber;
    @Alias("库存")
    private Integer stock;
    private String packaging;
    private String description;
    private Double price;
    private String datasheetUrl;
}