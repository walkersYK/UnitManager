package com.zhiyi.service.impl;

import com.zhiyi.common.ErrorCode;
import com.zhiyi.exception.BusinessException;
import com.zhiyi.mapper.UserMapper;
import com.zhiyi.model.entity.User;
import com.zhiyi.service.UserService;
import com.zhiyi.model.vo.LoginUserVO;
import com.zhiyi.model.vo.UserVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import java.time.LocalDateTime;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

import static com.zhiyi.constant.UserConstant.USER_LOGIN_STATE;

/**
 * @ function Service层调用Mapper接口的方法进行业务逻辑
 */

@Service

public class UserServiceImpl implements UserService {
    /**
     * 盐值，混淆密码
     */
    private static final String SALT = "yunjin";
    @Resource
    private UserMapper userMapper;

    @Override
    public List<User> queryUsersBySql(int currPage, int pageSize) {
        int currIndex = (currPage - 1) * pageSize;
        return userMapper.queryUsersBySql(currIndex, pageSize);
    }
    @Override
    public void addUser(User user) {
        userMapper.insertUser(user);
    }

    @Override
    public long userRegister(String userAccount, String userPassword) {
        /* 1. 校验 */
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (userAccount.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户账号过短");
        }
        if (userPassword.length() < 8 ) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户密码过短");
        }

        synchronized (userAccount.intern()) {
            // 账户不能重复
            User existingUser = userMapper.selectUserByAccount(userAccount);
            if (existingUser != null) {
                throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号重复");
            }
            // 2. 加密
            String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());
            // 3. 插入数据
            User user = new User();
            user.setUserAccount(userAccount);
            user.setUserPassword(encryptPassword);
            user.setUserRole("0");
            int insertResult = userMapper.insertUser(user);
            if (insertResult <= 0) {
                throw new BusinessException(ErrorCode.SYSTEM_ERROR, "注册失败，数据库错误");
            }
            return user.getId();
        }
    }

    @Override
    public void storeRememberMeToken(Long userId, String token) {
        User user = userMapper.selectUserById(userId);
        user.setUserProfile(token);
        userMapper.updateUser(user);

    }


    @Override
    public LoginUserVO userLogin(String userAccount, String userPassword, HttpServletRequest request) {
        // 1. 校验
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "参数为空");
        }
        if (userAccount.length() < 4) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "账号错误");
        }
        if (userPassword.length() < 8) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "密码错误");
        }
        // 2. 加密
        String encryptPassword = DigestUtils.md5DigestAsHex((SALT + userPassword).getBytes());
        // 查询用户是否存在
        User user = userMapper.selectByAccountAndPassword(userAccount, encryptPassword);
        // 用户不存在
        if (user == null) {
//            记录登录失败的日志
            System.out.println("user login failed, userAccount cannot match userPassword");
            throw new BusinessException(ErrorCode.PARAMS_ERROR, "用户不存在或密码错误");
        }
        // 3. 记录用户的登录态
        request.getSession().setAttribute(USER_LOGIN_STATE, user);
        return this.getLoginUserVO(user);
    }


    @Override
    public User getLoginUser(HttpServletRequest request) {

        return null;
    }

    @Override
    public User getLoginUserPermitNull(HttpServletRequest request) {
        return null;
    }

    @Override
    public boolean isAdmin(HttpServletRequest request) {
        return false;
    }

    @Override
    public boolean isAdmin(User user) {
        return false;
    }

    @Override
    public boolean userLogout(HttpServletRequest request) {
        return false;
    }

    @Override
    public LoginUserVO getLoginUserVO(User user) {
        if (user == null) {
            return null;
        }
        LoginUserVO loginUserVO = new LoginUserVO();
        loginUserVO.setId(user.getId());
        loginUserVO.setUserName(user.getUserName());
        loginUserVO.setUserAvatar(user.getUserAvatar());
        loginUserVO.setUserProfile(user.getUserProfile());
        loginUserVO.setUserRole(user.getUserRole());
        loginUserVO.setCreateTime(user.getCreateTime());
        loginUserVO.setUpdateTime(user.getUpdateTime());
        return loginUserVO;
    }

    @Override
    public UserVO getUserVO(User user) {
        return null;
    }

    @Override
    public List<UserVO> getUserVO(List<User> userList) {
        return null;
    }

    @Override
    public LoginUserVO userLogin(String userAccount, String userPassword) {
        return null;
    }

    @Override
    public User getUserByUsername(String userName) {
        return null;
    }
    @Override
    public boolean deleteUserById(Long id) {
        return userMapper.deleteUserById(id) > 0;
    }

    @Override
    public List<User> queryUsersBySql(int pageNum, int pageSize, String name) {
        // 调用 Mapper 方法进行分页查询和模糊匹配
        return userMapper.selectUsersByPageAndName((pageNum - 1) * pageSize, pageSize, name);
    }

}