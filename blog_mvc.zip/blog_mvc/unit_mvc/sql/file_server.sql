/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 50624
 Source Host           : localhost:3306
 Source Schema         : file_server

 Target Server Type    : MySQL
 Target Server Version : 50624
 File Encoding         : 65001

 Date: 31/12/2023 19:25:04
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for file_info
-- ----------------------------
DROP TABLE IF EXISTS `file_info`;
CREATE TABLE `file_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `file_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '文件名称',
  `MD5` binary(16) NOT NULL COMMENT '文件的MD5值',
  `create_time` datetime NOT NULL COMMENT '文件创建时间',
  `delete_state` bit(1) NOT NULL COMMENT '文件删除状态',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for fragment_info
-- ----------------------------
DROP TABLE IF EXISTS `fragment_info`;
CREATE TABLE `fragment_info`  (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `file_md5` binary(16) NOT NULL COMMENT '文件的MD5值',
  `fragment_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '分片文件名称',
  `fragment_order` int(11) NOT NULL COMMENT '分片文件序号',
  `md5` binary(16) NOT NULL COMMENT '分片文件的MD5值，采用转为16字节的数字存储',
  `path` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '分片文件存储路径',
  `size` int(11) NOT NULL COMMENT '分片文件大小，单位字节',
  `create_time` datetime NOT NULL COMMENT '分片文件创建时间',
  `delete_state` bit(1) NOT NULL COMMENT '删除状态（0表示未删除，1表示删除）',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
