package com.zhiyi.service.impl;

import com.zhiyi.mapper.UnitInventoryMapper;
import com.zhiyi.model.entity.UnitInventory;
import com.zhiyi.service.UnitInventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UnitInventoryServiceImpl implements UnitInventoryService {

    @Autowired
    private UnitInventoryMapper unitInventoryMapper;

    @Override
    public List<UnitInventory> findAll() {
        return unitInventoryMapper.findAll();
    }

    @Override
    public UnitInventory findById(Integer id) {
        return unitInventoryMapper.findById(id);
    }

    @Override
    public List<UnitInventory> findByUnitId(Integer unitId) {
        return (List<UnitInventory>) unitInventoryMapper.findById(unitId);
    }

    @Override
    public void save(UnitInventory unitInventory) {
        unitInventoryMapper.insert(unitInventory);
    }

    @Override
    public void update(UnitInventory unitInventory) {
        unitInventoryMapper.update(unitInventory);
    }

    @Override
    public void deleteById(Integer id) {
        unitInventoryMapper.deleteById(id);
    }
}