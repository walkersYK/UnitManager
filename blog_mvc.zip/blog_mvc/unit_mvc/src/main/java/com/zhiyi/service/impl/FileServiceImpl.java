package com.zhiyi.service.impl;


import com.zhiyi.mapper.FileMapper;
import com.zhiyi.model.entity.FilePO;
import com.zhiyi.service.FileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class FileServiceImpl implements FileService {
    @Resource
    private FileMapper fileMapper;

    @Override
    public Integer addFile(FilePO filePO) {
        return fileMapper.insertFile(filePO);
    }

    @Override
    public Boolean selectFileByMd5(String md5) {
        FilePO filePO = fileMapper.selectFileByMd5(md5);
        return filePO != null;
    }

    @Override
    public List<FilePO> selectFileList() {
        List<FilePO> list = fileMapper.selectFileList();
        return  list;
    }

    @Override
    public boolean deleteBatch(List<Integer> ids) {
        try {
            return fileMapper.deleteBatch(ids) > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
