package com.zhiyi.mapper;

import com.zhiyi.model.entity.FilePO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface FileMapper {
    public Integer insertFile(FilePO filePO) ;

    FilePO selectFileByMd5(String md5);

    List<FilePO> selectFileList();

    int deleteBatch(@Param("ids") List<Integer> ids);
}
