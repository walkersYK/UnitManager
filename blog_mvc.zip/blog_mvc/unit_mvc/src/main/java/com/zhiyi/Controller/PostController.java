package com.zhiyi.Controller;

import com.zhiyi.model.entity.Post;
import com.zhiyi.model.entity.UnitInventory;
import com.zhiyi.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/posts")
public class PostController {

    @Resource
    private PostService postService;

    @GetMapping("/all")
    public List<Post> getAllPosts() {
        return postService.findAll();
    }

    @GetMapping("/{id}")
    public Post getPostById(@PathVariable Long id) {
        return postService.findById(id);
    }

    @PostMapping("/add")
    public void addPost(@RequestBody Post post) {
        postService.save(post);
    }

    @PutMapping("/{id}")
    public void updatePost(@PathVariable Long id, @RequestBody Post post) {
        post.setId(id);
        postService.update(post);
    }
    @PostMapping("/update")
    public void update(@RequestBody Post post) {
        postService.update(post);
    }

    @DeleteMapping("/{id}")
    public void deletePost(@PathVariable Long id) {
        postService.deleteById(id);
    }

    @GetMapping("/search")
    public List<Post> searchPostsByTitle(@RequestParam String title) {
        return postService.findByTitle(title);
    }
}