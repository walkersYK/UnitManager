package com.zhiyi.mapper;

import com.zhiyi.model.entity.User;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author YunJin
 * @version 1.0
 * @description: TODO
 * @date 2024/11/26 16:54
 */
@Repository
public interface UserMapper {

    List<User> selectAllUsers();

    User selectUserByAccount(@Param("userAccount") String userAccount);

    User selectByAccountAndPassword(@Param("userAccount") String userAccount, @Param("userPassword") String userPassword);

    User selectUserById(@Param("id") Long id);

    int insertUser(User user);

    int updateUser(User user);

    int deleteUserById(@Param("id") Long id);

    List<User> queryUsersBySql(@Param("currIndex") int currIndex, @Param("pageSize") int pageSize);
    User selectByUsername(@Param("userName") String userName);
    List<User> selectUsersByPageAndName(@Param("offset") int offset, @Param("limit") int limit, @Param("name") String name);
}