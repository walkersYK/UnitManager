package com.zhiyi.Controller;

import com.zhiyi.common.ErrorCode;
import com.zhiyi.common.ResultUtils;
import com.zhiyi.model.entity.Unit;
import com.alibaba.excel.EasyExcel;
import com.zhiyi.common.BaseResponse;
import com.zhiyi.common.UnitDataListener;
import com.zhiyi.model.entity.ChunkPO;
import com.zhiyi.model.entity.FilePO;
import com.zhiyi.model.entity.Result;
import com.zhiyi.service.ChunkService;
import com.zhiyi.service.FileService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * 文件上传接口
 */
@RestController
@CrossOrigin
public class FileController {
    Logger logger = Logger.getLogger(getClass());

    @Value("${file.path}")
    private String filePath;

    @Resource
    private FileService fileService;
    @Resource
    private ChunkService chunkService;
    @GetMapping("/check")
    public Result checkFile(@RequestParam("md5") String md5){
        logger.info("检查MD5:"+md5);
        //首先检查是否有完整的文件
        Boolean isUploaded = fileService.selectFileByMd5(md5);
        Map<String, Object> data = new HashMap<>();
        data.put("isUploaded",isUploaded);
        //如果有，就返回秒传
        if(isUploaded){
            return new Result(201,"文件已经秒传",data);
        }

        //如果没有，就查找分片信息，并返回给前端
        List<Integer> chunkList = chunkService.selectChunkListByMd5(md5);
        data.put("chunkList",chunkList);
        return  new Result(201,"",data);
    }

    @PostMapping("/upload/chunk")
    public Result uploadChunk(@RequestParam("chunk") MultipartFile chunk,
                              @RequestParam("md5") String md5,
                              @RequestParam("index") Integer index,
                              @RequestParam("chunkTotal")Integer chunkTotal,
                              @RequestParam("fileSize")Long fileSize,
                              @RequestParam("fileName")String fileName,
                              @RequestParam("chunkSize")Long chunkSize
    ){


        String[] splits = fileName.split("\\.");
        String type = splits[splits.length-1];
        String resultFileName = filePath+md5+"."+type;

        chunkService.saveChunk(chunk,md5,index,chunkSize,resultFileName);
        logger.info("上传分片："+index +" ,"+chunkTotal+","+fileName+","+resultFileName);
        if(Objects.equals(index, chunkTotal)){
            FilePO filePO = new FilePO(fileName, md5, fileSize);
            fileService.addFile(filePO);
            chunkService.deleteChunkByMd5(md5);
            return  new Result(200,"文件上传成功",index);
        }else{
            return new Result(201,"分片上传成功",index);
        }

    }

    @GetMapping("/fileList")
    public Result getFileList(){
        logger.info("查询文件列表");
        List<FilePO> fileList = fileService.selectFileList();

        return  new Result(201,"文件列表查询成功",fileList);
    }

    @PostMapping("/del/batch")
    public Result deleteBatch(@RequestBody List<Integer> ids) {
        boolean success = fileService.deleteBatch(ids);
        if (success) {
            return new Result(200, "批量删除成功", success);
        } else {
            return new Result(400,"批量删除失败","fail");
        }
    }

    @PostMapping
    public BaseResponse<Unit> genChartByAi(@RequestParam("file") MultipartFile file,
                                        @ModelAttribute Unit genChartByAiRequest,
                                        HttpServletRequest request) {
        try (InputStream inputStream = file.getInputStream()) {
            // 使用 EasyExcel 解析 Excel 文件
            EasyExcel.read(inputStream, Unit.class, new UnitDataListener()).sheet().doRead();
            return null;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtils.error(ErrorCode.PARAMS_ERROR);
        }
    }
}
