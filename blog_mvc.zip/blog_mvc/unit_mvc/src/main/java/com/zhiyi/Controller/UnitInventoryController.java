package com.zhiyi.Controller;

import com.zhiyi.model.entity.UnitInventory;
import com.zhiyi.service.UnitInventoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/unit-inventory")
public class UnitInventoryController {

    @Resource
    private UnitInventoryService unitInventoryService;

    @GetMapping("/all")
    public List<UnitInventory> findAll() {
        return unitInventoryService.findAll();
    }

    @GetMapping("/{id}")
    public UnitInventory findById(@PathVariable Integer id) {
        return unitInventoryService.findById(id);
    }

    @GetMapping("/unit/{unitId}")
    public List<UnitInventory> findByUnitId(@PathVariable Integer unitId) {
        return unitInventoryService.findByUnitId(unitId);
    }

    @PostMapping
    public void save(@RequestBody UnitInventory unitInventory) {
        unitInventoryService.save(unitInventory);
    }

    @PutMapping
    public void update(@RequestBody UnitInventory unitInventory) {
        unitInventoryService.update(unitInventory);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Integer id) {
        unitInventoryService.deleteById(id);
    }
}