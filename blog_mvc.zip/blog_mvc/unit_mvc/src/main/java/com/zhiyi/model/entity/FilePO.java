package com.zhiyi.model.entity;

import lombok.Data;

@Data
public class FilePO {
    Integer fileId;
    String md5;
    String name;
    Long size;


    public FilePO(String name, String md5, Long size) {

        this.md5 = md5;
        this.name = name;
        this.size = size;
    }

    public FilePO() {
    }

    @Override
    public String toString() {
        return "FilePO{" +
                "fileId=" + fileId +
                ", md5='" + md5 + '\'' +

                ", name='" + name + '\'' +
                ", size=" + size +
                '}';
    }
}
