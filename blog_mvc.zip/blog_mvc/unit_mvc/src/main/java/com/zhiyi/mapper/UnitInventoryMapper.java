package com.zhiyi.mapper;

import com.zhiyi.model.entity.UnitInventory;
import org.apache.ibatis.annotations.*;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UnitInventoryMapper {

    List<UnitInventory> findAll();


    UnitInventory findById(@Param("id") Integer id);


    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(UnitInventory unitInventory);


    void update(UnitInventory unitInventory);


    void deleteById(@Param("id") Integer id);
}