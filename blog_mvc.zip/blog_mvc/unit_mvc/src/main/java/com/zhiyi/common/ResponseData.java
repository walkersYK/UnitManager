package com.zhiyi.common;

import java.util.HashMap;
import java.util.Map;

public class ResponseData {

    private final String message;
    private final int code;
    private final Map<String, Object> data = new HashMap<>();

    private ResponseData(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public static com.zhiyi.common.ResponseData ok() {
        return new com.zhiyi.common.ResponseData(200, "Ok");
    }

    public static com.zhiyi.common.ResponseData notFound() {
        return new com.zhiyi.common.ResponseData(404, "Not Found");
    }

    // 错误请求
    public static com.zhiyi.common.ResponseData badRequest() {
        return new com.zhiyi.common.ResponseData(400, "Bad Request");
    }

    // 禁止
    public static com.zhiyi.common.ResponseData forbidden() {
        return new com.zhiyi.common.ResponseData(403, "Forbidden");
    }

    // 无权限
    public static com.zhiyi.common.ResponseData unauthorized() {
        return new com.zhiyi.common.ResponseData(401, "unauthorized");
    }

    // 服务器内部错误
    public static com.zhiyi.common.ResponseData serverInternalError() {
        return new com.zhiyi.common.ResponseData(500, "Server Internal Error");
    }

    public static com.zhiyi.common.ResponseData customerError() {
        return new com.zhiyi.common.ResponseData(100, "customer Error");
    }


    public com.zhiyi.common.ResponseData putDataValue(String key, Object value) {
        data.put(key, value);
        return this;
    }

    // getters
    public String getMessage() {
        return message;
    }

    public int getCode() {
        return code;
    }

    public Map<String, Object> getData() {
        return data;
    }
}
