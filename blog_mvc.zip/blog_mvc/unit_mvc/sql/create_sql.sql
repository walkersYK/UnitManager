create database if not exists zhiyihouse;

use zhiyihouse;


-- 帖子表
create table if not exists post
(
    id         bigint auto_increment comment 'id' primary key,
    title      varchar(512)                       null comment '标题',
    content    text                               null comment '内容',
    tags       varchar(1024)                      null comment '标签列表（json 数组）',
    thumbNum   int      default 0                 not null comment '点赞数',
    favourNum  int      default 0                 not null comment '收藏数',
    userId     bigint                             not null comment '创建用户 id',
    createTime datetime default CURRENT_TIMESTAMP not null comment '创建时间',
    updateTime datetime default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete   tinyint  default 0                 not null comment '是否删除',
    index idx_userId (userId)
) comment '帖子' collate = utf8mb4_unicode_ci;



-- 用户表
create table if not exists user
(
    id           bigint auto_increment comment 'id' primary key,
    userAccount  varchar(256)                           not null comment '账号',
    userPassword varchar(512)                           not null comment '密码',
    unionId      varchar(256)                           null comment '微信开放平台id',
    mpOpenId     varchar(256)                           null comment '公众号openId',
    userName     varchar(256)                           null comment '用户昵称',
    userAvatar   varchar(1024)                          null comment '用户头像',
    userProfile  varchar(512)                           null comment '用户简介',
    userRole     varchar(256) default 'user'            not null comment '用户角色：user/admin/ban',
    createTime   datetime     default CURRENT_TIMESTAMP not null comment '创建时间',
    updateTime   datetime     default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete     tinyint      default 0                 not null comment '是否删除',
    index idx_unionId (unionId)
) comment '用户' collate = utf8mb4_unicode_ci;
use zhiyihouse;
ALTER TABLE user
    ADD COLUMN lastActivityTime DATETIME DEFAULT CURRENT_TIMESTAMP NOT NULL COMMENT '最后活动时间' ON UPDATE CURRENT_TIMESTAMP;
-- 文件
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for chunk
-- ----------------------------
DROP TABLE IF EXISTS `chunk`;
CREATE TABLE `chunk`  (
                          `c_id` int NOT NULL AUTO_INCREMENT,
                          `c_md5` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
                          `c_index` int NULL DEFAULT NULL,
                          PRIMARY KEY (`c_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3834 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for file
-- ----------------------------
DROP TABLE IF EXISTS `file`;
CREATE TABLE `file`  (
                         `f_id` int NOT NULL AUTO_INCREMENT,
                         `f_md5` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
                         `f_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
                         `f_size` bigint NULL DEFAULT NULL,
                         PRIMARY KEY (`f_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 33 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

SET FOREIGN_KEY_CHECKS = 1;

-- 器件表
CREATE TABLE unit (
                      id INT AUTO_INCREMENT PRIMARY KEY, -- 添加唯一标识符
                      device_name VARCHAR(255) NOT NULL, -- 器件名
                      model_number VARCHAR(255) NOT NULL, -- 型号
                      stock INT NOT NULL DEFAULT 0, -- 库存
                      packaging VARCHAR(100), -- 封装
                      description TEXT, -- 描述
                      price DECIMAL(10, 2) NOT NULL, -- 价格，支持两位小数
                      datasheet_url VARCHAR(255) -- 数据手册链接
);


-- auto-generated definition
create table unit_inventory
(
    id            int auto_increment
        primary key,
    unit_id       int                                 not null comment '元器件ID',
    stock         int                                 not null comment '当前库存量',
    last_modified timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '最后修改时间',
    modifier_id   int                                 not null comment '最后修改人ID',
    modifier_name varchar(256)                        not null comment '最后修改人名称',
    change_reason text                                null comment '变更原因',
    constraint fk_unit_inventory_unit foreign key (unit_id) references unit (id)
);

-- auto-generated definition
create table post_comments
(
    id          bigint auto_increment comment '评论ID'
        primary key,
    postId      bigint                              not null comment '帖子ID',
    userId      bigint                              not null comment '用户ID',
    userName    varchar(256)                        not null comment '用户名',
    content     text                                not null comment '评论内容',
    created_at  timestamp default CURRENT_TIMESTAMP not null comment '创建时间',
    updated_at  timestamp default CURRENT_TIMESTAMP not null on update CURRENT_TIMESTAMP comment '更新时间',
    isDelete    tinyint      default 0              not null comment '是否删除',
    constraint uc_post_user unique (postId, userName)
);
