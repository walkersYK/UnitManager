package com.zhiyi.service;


import com.zhiyi.model.entity.FilePO;

import java.util.List;

public interface FileService {
    Integer addFile(FilePO filePO);

    Boolean selectFileByMd5(String md5);

    List<FilePO> selectFileList();

    boolean deleteBatch(List<Integer> ids);
}
