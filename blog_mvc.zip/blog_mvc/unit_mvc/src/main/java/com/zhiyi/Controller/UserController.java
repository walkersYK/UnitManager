package com.zhiyi.Controller;

import cn.hutool.core.io.FileUtil;
import com.zhiyi.model.entity.User;
import com.zhiyi.service.UserService;
import com.zhiyi.common.BaseResponse;
import com.zhiyi.common.ErrorCode;
import com.zhiyi.common.ResultUtils;
import com.zhiyi.exception.BusinessException;
import com.zhiyi.model.dto.user.UserLoginRequest;
import com.zhiyi.model.dto.user.UserRegisterRequest;
import com.zhiyi.model.vo.LoginUserVO;
import com.zhiyi.utils.JWTUtil;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

/**
 * 用户接口
 *
 */
@RestController
public class UserController {

    @Resource
    private UserService userService;
    @Value("${ip}")
    String ip;

    @Value("${server.port}")
    String port;

    private static final String ROOT_PATH =  System.getProperty("user.dir") + File.separator + "files";

    @PostMapping("/register")
    public BaseResponse<Long> userRegister(@RequestBody UserRegisterRequest userRegisterRequest) {
        if (userRegisterRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        String userAccount = userRegisterRequest.getUserAccount();
        String userPassword = userRegisterRequest.getUserPassword();
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            return null;
        }
        long result = userService.userRegister(userAccount, userPassword);
        return ResultUtils.success(result);
    }
    /**
     * 用户登录
     *
     * @param userLoginRequest
     * HttpServletRequest 获取请求信息
     * HttpServletResponse 设置响应信息
     * @param request
     * @return
     */
    @PostMapping("/login")
    public BaseResponse<LoginUserVO> userLogin(@RequestBody UserLoginRequest userLoginRequest, HttpServletRequest request, HttpServletResponse response) {
        if (userLoginRequest == null) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }
        String userAccount = userLoginRequest.getUserAccount();
        String userPassword = userLoginRequest.getUserPassword();
        if (StringUtils.isAnyBlank(userAccount, userPassword)) {
            throw new BusinessException(ErrorCode.PARAMS_ERROR);
        }

        // 验证用户信息并获取用户数据
        LoginUserVO loginUserVO = userService.userLogin(userAccount, userPassword, request);
        // 生成token
        String token = JWTUtil.generateToken(String.valueOf(loginUserVO.getId()), "Jersey-Security-Basic", loginUserVO.getUserName());
        loginUserVO.setToken(token);
        System.out.println(token);
        return ResultUtils.success(loginUserVO);
    }

    @GetMapping("/searchByName/{userName}")
    public User searchUserByName(@PathVariable String userName) {
        return userService.getUserByUsername(userName);
    }

    @GetMapping("/users")
    public BaseResponse<List<User>> queryUsersBySql(
            @RequestParam(value = "page", defaultValue = "1") int pageNum,
            @RequestParam(value = "size", defaultValue = "10") int pageSize,
            @RequestParam(value = "name", required = false) String name) {
        List<User> pageUser = userService.queryUsersBySql(pageNum, pageSize, name);
        return ResultUtils.success(pageUser);
    }

    @PostMapping("/upload")//上传头像接口
    public BaseResponse<String> upload(MultipartFile file) throws IOException {
        String originalFilename = file.getOriginalFilename();  // 文件的原始名称
        // aaa.png
        String mainName = FileUtil.mainName(originalFilename);  // aaa
        String extName = FileUtil.extName("文件的后缀");// png
        String projectPath = System.getProperty("user.dir");
        String filePath = projectPath + "\\files";
        File parentFile = new File(filePath);
        if (!parentFile.exists()) {
            parentFile.mkdirs();  // 如果当前文件的父级目录不存在，就创建
        }
        File saveFile = new File(filePath + File.separator+ originalFilename);
        if (saveFile.exists()) {  // 如果当前上传的文件已经存在了，那么这个时候我就要重名一个文件名称
            originalFilename = System.currentTimeMillis() + "_" + mainName + "." + extName;
            saveFile = new File(filePath + File.separator+ originalFilename);
        }
        file.transferTo(saveFile);  // 存储文件到本地的磁盘里面去
        String url = "http://" + ip + ":" + port + "/files/" + originalFilename;
        return ResultUtils.success(url);  //返回文件的链接，这个链接就是文件的下载地址，这个下载地址就是后台提供出来的
    }

    @DeleteMapping("/delete/{id}")
    public BaseResponse<String> deleteUser(@PathVariable Long id) {
        boolean result = userService.deleteUserById(id);
        return ResultUtils.success("删除成功");
    }

    @PostMapping("/add")
    public String addUser(@RequestBody User user) {
        userService.addUser(user);
        return "User added successfully";
    }

}