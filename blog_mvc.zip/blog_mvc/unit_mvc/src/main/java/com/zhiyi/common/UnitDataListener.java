package com.zhiyi.common;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.zhiyi.model.entity.Unit;
import com.zhiyi.mapper.UnitMapper;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;

@Component
public class UnitDataListener extends AnalysisEventListener<Unit> {

    @Resource
    private UnitMapper unitMapper;

    @Override
    public void invoke(Unit data, AnalysisContext context) {
        // 每解析一行数据调用一次
        unitMapper.insert(data);
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext context) {
        // 所有数据解析完成后的操作
    }

//    @Override
//    public void invokeHeadMap(List<String> headMap, AnalysisContext context) {
//        // 头部信息处理
//        super.invokeHeadMap(headMap, context);
//    }
}