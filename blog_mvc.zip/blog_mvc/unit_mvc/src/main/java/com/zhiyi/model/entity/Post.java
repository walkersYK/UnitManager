package com.zhiyi.model.entity;

import lombok.Data;

import java.util.Date;
@Data
public class Post {
    private Long id;
    private String title;
    private String content;
    private String tags;
    private Integer thumbNum;
    private Integer favourNum;
    private Long userId;
    private Date createTime;
    private Date updateTime;
    private Integer isDelete;

    // Getters and Setters
}